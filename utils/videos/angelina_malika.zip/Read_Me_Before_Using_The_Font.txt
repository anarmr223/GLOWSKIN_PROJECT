﻿========================================================
  IMPORTANT NOTICE – PLEASE READ BEFORE USING THIS FONT
========================================================

Thank you for downloading this font.

LICENSE TERMS:
---------------
✔ FREE for DEMO and PERSONAL USE only.
✘ COMMERCIAL USE IS STRICTLY PROHIBITED without a valid license.

If you wish to use this font for any COMMERCIAL PURPOSE, you MUST purchase the appropriate license from our official website:

������ https://letterhanna.com

To use swash, beginning swash, ending swash and stylistic alternate letters, you can read the guide at my website :
https://letterhanna.com/font-guide/



SUPPORT THE DESIGNER:
---------------------
If you love this font and want to support the designer, you can send a donation here:

������ https://paypal.me/aldohsb

Your support will help us create more beautiful fonts in the future.

Thank you for respecting our work.

Studio Letterhanna
https://letterhanna.com
========================================================